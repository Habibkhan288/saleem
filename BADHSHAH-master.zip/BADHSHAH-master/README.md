# BADHSHAH
This tool is for Cloning fb id. 
This is for Educatinal purpose only.
